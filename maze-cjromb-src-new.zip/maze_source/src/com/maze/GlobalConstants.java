package com.maze;

/**
 * Constants used to calculate the maze cell properties and text for storing direction
 *
 * The first direction items are the bitwise constants that increment 1, 2, 4, 8, 16, 32, 64
 * They are used to calculate properties of the cell
 *
 * The second set of constants are used as utilities so I don't have to type quotation marks and text. :)
 *
 * The NUM_MINES_ALLOWED constant is the number of mines per path allowed for any maze solution
 */
public interface GlobalConstants {


        int UP = 1;
        int RIGHT = UP << 1;
        int DOWN = UP << 2;
        int LEFT = UP << 3;
        int START = UP << 4;
        int END = UP << 5;
        int MINE = UP << 6;

        String U = "up";
        String D = "down";
        String R = "right";
        String L = "left";

        int NUM_MINES_ALLOWED = 3;

}
