package com.maze;

import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.Nullable;

import java.util.*;

/**
 * Utilities for solving and getting information about the maze. solveMaze is the core function, so it comes first.
 * The other functions called by solveMaze follow solveMaze.
 * Other utility functions come after that.
 */
class Maze {

    private final Integer numMinesAllowed; // total mines allowed for maze

    private LinkedList<MazeNode> mazeNodesMatrix = new LinkedList<>();

    private final HashMap<MazePoint, MazePoint> visited = new HashMap<>();

    private final MazePoint matrixDimensions; // x and y of matrix
    private final MazePoint startPoint;

    public Maze(MazeInfo mazeInfo)
    {
        this.startPoint = mazeInfo.getStartPoint();
        this.mazeNodesMatrix = mazeInfo.getMazeNodesMatrix();
        this.numMinesAllowed = mazeInfo.getNumMinesAllowed();
        this.matrixDimensions = mazeInfo.getMatrixDimensions();
    }

    /**
     * Core function for solving the maze
     * @return MazePoint cell address for the end path
     */
    public MazePoint solveMaze()
    {
        // make a visited list to check against

        MazeNode startNode;

        // make a queue
        PriorityQueue<MazeNode> q = new PriorityQueue<>(getNumCells(), Comparator.comparingInt(MazeNode::getLevel));

        startNode = setStartNode(mazeNodesMatrix, startPoint, numMinesAllowed);

        q.add(startNode);

        while (!q.isEmpty())
        {
            // get the top node from queue
            MazeNode current;
            MazePoint currCell;

            current = q.poll();

            currCell = current.getCell();  // MazeNode

            // if visited, don't bother with this cell
            if (isVisited(currCell)) continue;

            // if not, add this cell to visited
            visited.put(currCell, null);

            // MazeNode functions
            if (current.isEnd()) return currCell;
            if (current.getMinesLeft() <= 0) continue;
            if (current.isMineCell()) { current.reduceMinesLeft(); }
            if (current.getMinesLeft() == 0) continue;
            // end MazeNode functions

            // get the children (children of this cell)
            processChildren(current, currCell, q);

        } // while there's content in the queue
        return null;
    }


    /**
     * Sets up the information for the starting node of the maze.
     * @param mazeNodesMatrix the list of maze nodes.  each maze node contains all of the information about a cell
     * @param startPoint the address of the starting point for the maze
     * @param numMinesAllowed the number of mines allowed per path.
     * @return MazeNode the starting mazenode with all the necessary information to start the maze solution
     */
    private MazeNode setStartNode(LinkedList<MazeNode> mazeNodesMatrix, MazePoint startPoint, Integer numMinesAllowed)
    {

        // System.out.println("num mines allowed in setStartNode" + numMinesAllowed);
        LinkedList<String> pathTrack = new LinkedList<>();

        //get the start node from the matrix of MazeNodes
        MazeNode startNode = findMazeNode(mazeNodesMatrix, startPoint);

        assert startNode != null;
        startNode.setLevel(0);
        startNode.setMinesLeft(numMinesAllowed);
        startNode.setParent(new MazePoint(-1, -1));
        startNode.setPathTrack(pathTrack);  // empty because start node

        //      startNode.print();

        mazeNodesMatrix.add(startNode);
        return startNode;
    }

    /**
     * Processes the children of a queue item.  Then adds the children to the queue, when they haven't been visited
     * and if the path isn't out of lives.
     * @param current The current cell's information (MazeNode)
     * @param currCell The current cell address being processed
     * @param q Queue for processing MazeNodes
     */
    private void processChildren(MazeNode current, MazePoint currCell, PriorityQueue<MazeNode> q)
    {
        // not visited yet
        // get their original mazeNodesMatrix record
        int childLevel;
        LinkedList<MazeNode> qChildren;
        MazePoint parentCell;

        qChildren = new LinkedList<>(current.getChildren());

        parentCell = currCell;
        childLevel = current.getLevel() + 1;

        for (MazeNode qChild : qChildren)
        {
            processChild(q, qChild, current, parentCell, childLevel);

        } // end for each child

    } // end processChildren

    /**
     * Processes an individual child of the current cell.
     * Adds it to the end of the queue for further inspection, when it's a parent.
     * @param q The processing queue
     * @param qChild The cell address of the child being processed
     * @param current The cell information about the parent asking for the processing
     * @param parentCell The parent's cell address
     * @param childLevel The level the child belongs to - this is a breadth first search.
     */
    private void processChild(PriorityQueue<MazeNode> q, MazeNode qChild, MazeNode current,
                              MazePoint parentCell, int childLevel)
    {

        LinkedList<String> pathTrack = new LinkedList<>();
        LinkedList<String> newPathTrack = new LinkedList<>();
        // MazeNode mChildNode = new MazeNode();
        MazeNode mParentNode;
        MazePoint qChildCell;

        String direction;

        qChildCell = qChild.getCell();

        // have to check here for visited I think, because I don't want to
        // be resetting stuff that's been set!
        if (isVisited(qChildCell)) return;

        //  System.out.println("The size of the mazeNodes Matrix is" + mazeNodesMatrix.size());
        MazeNode mChildNode = findMazeNode(mazeNodesMatrix, qChildCell);

        // mChildNode = getMazeNode(matrix, qChildCell);

        // curr cell is this cells parent
        mChildNode.setParent(parentCell);  // MazeNode Function

        // set the matrix mines allowed to whatever the parent mines allowed is

        mChildNode.setMinesLeft(current.getMinesLeft());

        // should be empty, because not visited
        mParentNode = findMazeNode(mazeNodesMatrix, parentCell);
        // mParentNode = getMazeNode(matrix, parentCell);

        try
        {
            pathTrack = mParentNode != null ? mParentNode.getPathTrack() : null;

        } catch (NullPointerException npe) {

        }

        // create child's own path track using parents + child's directions
        // cycle through parent's path track
        if (pathTrack != null)
        {
            for (String each : pathTrack)
            {
                newPathTrack.add(each);
            }
        }

        // add child's direction to the path track and then store it in child's cell
        direction = qChild.getDirection();
        mChildNode.setDirection(direction);
        newPathTrack.add(direction);
        mChildNode.setPathTrack(newPathTrack);

        // child's level is your parents level + 1
        mChildNode.setLevel(childLevel);

        // add it to the queue for processing
        q.add(mChildNode);

        return;

    }

    /**
     * Builds the string for printing after solving
     * @param endPath The string contained in the maze node of information for the last cell
     * @return String containing the solution path for the maze
     */
    private String buildMazePathString(LinkedList<String> endPath)
    {

        StringJoiner joiner = new StringJoiner("','", "['", "']");
        int counter = 0;

        for(String each : endPath)
        {
            ++counter;
            joiner.add(each);
        }

        //   System.out.println("There are " + counter + "items in the path");

        return joiner.toString();
    }

    /**
     * Prints the final solution for the maze
     * @param endCell The last cell of the maze
     * @param mazeNodesMatrix The list of MazeNodes.  Each list item contains the information for one cell
     */
    void printSolution(MazePoint endCell, LinkedList<MazeNode> mazeNodesMatrix)
    {
        MazeNode endNode;
        LinkedList<String> endPath = new LinkedList<>();
        String outputPath;

        endNode = findMazeNode(mazeNodesMatrix, endCell);
        try {
            endPath = endNode != null ? endNode.getPathTrack() : null;

        } catch (NullPointerException e) {
            System.out.println("No path was found through maze.");
        }

        if (endPath != null) {
            outputPath = buildMazePathString(endPath);
            System.out.println(outputPath);
        }
    }

    /**
     * Utility for finding a Maze Node, given its x, y coordinates
     * @param mazeNodesMatrix The list of nodes for the matrix
     * @param searchPoint The cell address of the desired node
     * @return MazeNode the maze node stored for the search point's address
     */
    @Nullable
    private MazeNode findMazeNode(LinkedList<MazeNode> mazeNodesMatrix, MazePoint searchPoint)
    {
        for( MazeNode each : mazeNodesMatrix)
        {
            if (each.getCell().equals(searchPoint)) {
                return each;
            }
        }
        return null;

    }

    /**
     * Gets the number of cells in the maze
     * @return number of cells in the maze
     */
    @Contract(pure = true)
    private int getNumCells() {
        return this.matrixDimensions.x * this.matrixDimensions.y;
    }

    /**
     * Has this cell already been been visited
     * @param cell cell address
     * @return boolean has this cell been visited?
     */
    private boolean isVisited(MazePoint cell)
    {
        return this.visited.containsKey(cell);
    }


} // end class Maze