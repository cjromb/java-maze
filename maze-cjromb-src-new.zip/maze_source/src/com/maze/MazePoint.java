package com.maze;

/**
 * Data Storage class for holding value of row (x) and col (y)
 * @author cjromberger
 */
class MazePoint {
    int x, y;

    MazePoint (int x, int y) {
        this.x = x; this.y = y;
    }

    /**
     * Overrides the Object.equals function.
     * Checks to see if the x and y values are the same, which constitutes equivalent.
     * @param obj The MazePoint object to be examined.
     * @return boolean is the MazePoint equal to the other MazePoint?
     */
    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (!MazePoint.class.isAssignableFrom(obj.getClass())) {
            return false;
        }
        final MazePoint other = (MazePoint) obj;

        return Integer.valueOf(x).equals(other.x) && Integer.valueOf(y).equals(other.y);

    }

    /**
     * Checks to see if the cell address is set.
     * @param mp The coordinates of the cell being checked.
     * @return boolean is the cell address set
     */
    public boolean isSet(MazePoint mp) {
        return !((mp.x == -1) || (mp.y == -1));
    }

    /**
     * Sets the x and y coordinates of a cell.
     * @param x row of a cell
     * @param y column of a cell
     */
    public void setMazePoints(int x, int y) {
        this.x = x; this.y = y;
    }

    /**
     * Returns a string with the x and y coordinates of a cell.  Debugging purposes only.
     * @return String with x and y coordinates of a cell
     */
    public String getMazePointString() { return "x:" + this.x + " y:" + this.y; }

    /**
     * Prints a string with the x and y coordinates of a cell.  Debugging purposes only.
     * This version doesn't print a new line.  See printLine for a version that doesn't.
     */
    public void print() {
        System.out.print("x:" + this.x + " y:" + this.y);
    }

    /**
     * Prints a string with the x and y coordinates of a cell.  Debugging purposes only.
     * This version prints a new line.  See print() for version that doesn't.
     */
    public void printLine() {System.out.println("x:" + this.x + " y:" + this.y);}

}