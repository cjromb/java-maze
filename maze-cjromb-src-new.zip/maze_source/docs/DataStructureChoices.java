package com.maze.java;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 *
 */
public class DataStructureChoices {

    public static void main(String[] args) {

        // choosing which data structure to use in Java

        Scanner sc = new Scanner();

        // ask questions
        // when answer is figured out, give
        // more information like how to declare, add, remove, iterate, description, javadoc

        //Will it contain key value pairs or values only
        boolean keyValuePairs = false;
        boolean orderImportant = false;
        boolean insertionOrder = false;
        boolean keySorted = false;
        boolean valuesOnly = false;
        boolean duplicates = false;
        boolean searchRemovePrimary = false;
        boolean sorted = false;

        String choice = new String();
        Map<String, String> choices = new HashMap<String, String>();

        DataStructureChoices dsc = new DataStructureChoices();
        choices = dsc.createHashMap();

        // provide more information like how to declare, add, remove, iterate, description, javadoc
        if (keyValuePairs) {
            //   Is order Important
            if (!orderImportant) {
                choice = choices.get("hm");
            } else {
                // Insertion order or sorted by keys
                if (insertionOrder) {
                    choice = choices.get("tm");
                } else if (keySorted) {
                    choice = choices.get("lhm");

                } // end insertion order or key sorted
            } // end orderImportant
        } else if (valuesOnly) {
            // will it contain duplicates
            if (duplicates) {
                choice = "ArrayList";
            } else {
                // is primary task searching for elements (contains/removes)
                if (!searchRemovePrimary) {
                    choice = "ArrayList";
                } else {
                    // is order important
                    if (!orderImportant) {
                        choice = "HashSet"
                    } else {
                        // insertion order or sorted by values
                        if (insertionOrder) {
                            choice = "LinkedHashSet";
                        } else if (keySorted) {
                            choice = choices.get("ts");
                        } // end if insertion order or value sorted
                    } // end if order is important
                } // end if primary task is searching for elements (contains / removes)
            } // end if contains duplicates
        } // end if keyValuePairs or values only
    } // end main

    public HashMap<String, String> createHashMap() {

        choices.put("hm", "HashMap");
        choices.put("tm", "TreeMap");
        choices.put("lhm", "LinkedHashMap");
        choices.put("al", "ArrayList");
        choices.put("hs", "HashSet");
        choices.put("ts", "TreeSet");
        choices.put("lhs", "LinkedHashSet");

        return choices;
    }
} // end class

// other possible choice considerations
// traverse backwards - choose tree map instead of hashmap
// faster search, vs. insert vs. remove
// reordering indexes // linked in vs. array - losing keys
// see this google doc I made
// https://docs.google.com/spreadsheets/d/1bHAd9qXalyW0q6ziRTVO0n1CbK45I4oho_eH3r8VI_A/edit#gid=0

// flowchart http://stackoverflow.com/questions/48442/rule-of-thumb-for-choosing-an-implementation-of-a-java-collection
// link to more details broken