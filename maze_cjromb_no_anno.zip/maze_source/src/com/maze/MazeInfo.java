package com.maze;

import java.util.LinkedList;

/**
 * Used to store the maze information returning from maze parsing.
 * Passed to the solveMaze function
 * @author cjromberger
 */
class MazeInfo {

    private Integer numMinesAllowed;

    private LinkedList<MazeNode> mazeNodesMatrix;

    private MazePoint endPoint;
    private MazePoint matrixDimensions;
    private MazePoint startPoint;


    public MazeInfo() {

    }

    /**
     * gets the end point from the newly parsed maze information
     * @return MazePoint cell address from the end of the maze
     */
    MazePoint getEndPoint() {
        return endPoint;
    }

    /**
     * sets the end point from the newly parsed maze info before sending it off for solving.
     * @param endPoint the end point for the maze
     */
    void setEndPoint(MazePoint endPoint)
    {
        this.endPoint = endPoint;
    }

    /**
     * gets the dimensions of the maze (how many rows and columns)  Stores them in the two field class MazePoint
     * @return x and y values for the size of the matrix.  Using MazePoint to store them, even though it's not an
     * address, because it's convenient to reuse this class. :)
     */
    MazePoint getMatrixDimensions() {
        return matrixDimensions;
    }

    /**
     * sets the x and y values for the maze
     * @param matrixDimensions sets x and y values to represent the number of rows and columns in the maze.
     */
    public void setMatrixDimensions(MazePoint matrixDimensions)
    {
        this.matrixDimensions = matrixDimensions;
    }

    /**
     * gets the MazeNodes of cell information to send off for solving.
     * @return The list of Maze Nodes freshly parsed from the file.
     */
    public LinkedList<MazeNode> getMazeNodesMatrix() {return mazeNodesMatrix;}

    /**
     * Sets the mazeNodes lists of cell information after parsing it from the file.
     * @param mazeNodesMatrix the list of mazeNodes that store each cell's information
     */
    public void setMazeNodesMatrix(LinkedList<MazeNode> mazeNodesMatrix)
    {
        this.mazeNodesMatrix = mazeNodesMatrix;
    }

    /**
     * Sends back the base number of mines allowed per path.  This value is currently stored in GlobalConstants.
     * It could be input from another place, like a command line or user interface.
     * @return Integer how many mines are allowed per path in the maze?
     */
    public Integer getNumMinesAllowed() {
        return this.numMinesAllowed;
    }

    /**
     * Sets the number of mines allowed before sending back the maze information for solving.
     * @param numMinesAllowed sets the number of mines that are allowed per path in the maze.
     */
    public void setNumMinesAllowed(Integer numMinesAllowed)
    {
        this.numMinesAllowed = numMinesAllowed;
    }

    /**
     * Gets the starting point for the maze.
     * @return The cell address for the starting point.
     */
    public MazePoint getStartPoint() {
        return startPoint;
    }

    /**
     * sets the starting point for the maze after parsing before sending off for solving.
     * @param startPoint the starting address for the maze
     */
    public void setStartPoint(MazePoint startPoint)
    {
        this.startPoint = startPoint;
    }


}
