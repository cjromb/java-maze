package com.maze;

import java.io.IOException;
import java.lang.String;
import java.io.BufferedReader;
import java.io.FileReader;

/**
 *  Main class - Reads from a file, parses contents, solves maze and prints solution
 *  @author cjromberger
 */
class MazeMain  {

    private static final String FILENAME = "files/mazes.txt";
    //public static final boolean debug = true; // turns on debug printing

    /**
     * Main function for the maze program.  It reads each line from an input file, parses it,
     * calculates the properties of the maze and the maze contents, solves the maze,
     * and prints out the direction order for the solution.
     * @author cjromberger
     * @param args Incoming string array of command line arguments.  Not used for this program
     */
    public static void main(String[] args) {

        // Read the contents of the file in
        BufferedReader br = null;
        FileReader fr = null;

        try {

            // read in the file line
            br = new BufferedReader(new FileReader(FILENAME));

            String sCurrentLine;

            // use this counter to set which file line you want to test, if not running all of them.
    //        int mazeCounter = 0;

            while ((sCurrentLine = br.readLine()) != null) {

                // uncomment this to test a specific number of maze lines
       //      if(mazeCounter == 0) {

                MazeInfo mazeInfo = new MazeMaker().makeMaze(sCurrentLine);

                if (mazeInfo != null) {
                    Maze maze = new Maze(mazeInfo);
                    MazePoint endCell = maze.solveMaze();
                    maze.printSolution(endCell, mazeInfo.getMazeNodesMatrix());
                }

/*
            for debugging - uncomment, along with other debug lines above, to test smaller set of lines.
                     mazeCounter++;

                } else {
                      mazeCounter++;
                }
*/
            } // end while there are lines


        } catch (IOException e) {

            e.printStackTrace();

        } finally {

            try {

                if (br != null)
                    br.close();

            } catch (IOException ex) {

                ex.printStackTrace();

            }

        }
    }
}




