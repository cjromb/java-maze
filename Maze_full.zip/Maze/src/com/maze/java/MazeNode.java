package com.maze.java;

import org.jetbrains.annotations.Nullable;

import java.util.LinkedList;

/**
 * Node for storing data about each cell in the maze.
 * The constructors are first.
 * Getter/Setter functions are last.
 * The interesting functions are in between those two.
 */
class MazeNode {
    private boolean end = false;
    private boolean mine = false; // is this a mine cell?
    private boolean start = false;

    private int level;

    private Integer minesLeft; // at the moment it's found, how many mines are left?

    private LinkedList<MazeNode> children = new LinkedList<>(); // who's living next door
    private LinkedList<String> pathTrack; // will be backwards at first

    private MazePoint cell = null;
    private MazePoint parent = null;

    private String direction = null; // what direction was taken to arrive here

    // TODO find a data structure that adds to the top

    /******** CONSTRUCTORS ********/

    /**
     *
     * @param cell MazePoint address of current cell.
     * @param parent MazePoint address of cell traveled from
     * @param direction String direction traveled to arrive at cell
     * @param minesLeft Integer how many mines are left?
     */
    public MazeNode(MazePoint cell, MazePoint parent, String direction, Integer minesLeft) {
        this.cell = cell;
        this.parent = parent;
        this.direction = direction;
        this.pathTrack = new LinkedList<>();
        this.minesLeft = minesLeft;
    }

    /**
     *
     * @param cell Row and column address of cell
     */
    public MazeNode(MazePoint cell){

        this.cell = cell;
        this.pathTrack = new LinkedList<>();

    }


    /*  ******** OTHER METHODS *********  */
    /**
     * prints the contents of a mazeNode
     */
    public void print()
    {
        System.out.println("This Cell: ");
        this.getCell().print();
        System.out.println("Parent: ");
        this.getParent().print();
        System.out.println("Level: ");
        System.out.println(getLevel());
        System.out.print("Start? ");
        System.out.println(isStart());
        System.out.print("End? ");
        System.out.println(isEnd());
        System.out.print("Direction: ");
        System.out.println(getDirection());
        System.out.print("Mine Cell? ");
        System.out.println(isMineCell());
        System.out.println("AFTER mine cell");

        if(null != this.getMinesLeft()) {
            System.out.print("Mines Left: ");
            System.out.println(this.getMinesLeft());
        } else {
            System.out.println("What IS the mines left? ");
        }
        System.out.println("*************");
        System.out.println("Children: ");
        children = this.getChildren();
        if(children.size() > 0) {
            for (MazeNode child : children) {
                child.print();
            }
        }
    }

    /**
     * decrements the number of mines left for this path
     */
    public void reduceMinesLeft()
    {

        Integer minesLeft = this.getMinesLeft() - 1;
        this.setMinesLeft(minesLeft);

        if(minesLeft < 0)
        {
            this.getCell().print();
        }
    }

    /******* GETTERS / SETTERS *********/

    /**
     *
     * @return the address of the cell requested
     */
    public MazePoint getCell() {
        return this.cell;
    }

    /**
     * Gets the children (neighbors) of the current MazeNode cell
     * @return List of children MazeNodes for the children of the current cell
     */
    public LinkedList<MazeNode> getChildren() { return this.children; }

    /**
     * Sets the children (neighbors of the current MazeNode cell
     * @param children List of the current MazeNodes children
     */
    public void setChildren(LinkedList<MazeNode> children) { this.children = children; }

    /**
     * Gets the direction that was traveled to ARRIVE at this cell.
     * NOTE: This is NOT the direction for leaving the cell!
     * This is stored for the purposes of retracing the successful path steps after the maze is solved.
     * @return String the direction this cell was arrived from
     */
    public String getDirection() {
        return this.direction;
    }

    /**
     * Is this the end cell of the maze?
     * @return boolean is this the end of the cell
     */
    public boolean isEnd() {
        return this.end;
    }

    /**
     * This is the end cell of the maze, so set this information in its MazeNode
     */
    public void setEnd() {
        this.end = true;
    }

    /**
     * This is the level of the cell compared to the starting cell of the maze. This is a breadth first search.
     * @return Integer level of cell compared to starting cell during maze solution.
     */
    public Integer getLevel() {
        return this.level;
    }

    /**
     * This sets the level of the cell compared to the starting cell of the maze.
     * This is a breadth first search.  This would be more important if ALL paths were being tracked.
     * @param level level to set for this cell
     */
    public void setLevel(Integer level) { this.level = level; }

    /**
     * Uh-oh.  This is a mine cell.  If the path hits the NUM_MINES_ALLOWED number, the path is dead.
     * If this were a visual mine, this cell would be scary looking.
     */
    public void setMine() {
        this.mine = true;
    }

    /**
     * Is this a mine cell?
     * @return boolean is this a mine cell?
     */
    public boolean isMineCell() {
        return this.mine;
    }

    /**
     * How many mines are left? When the children are first created, this could possibly be null.
     * It will be set while the maze is being solved.
     * @return integer number of mines remaining on this path.
     */
    @Nullable
    public Integer getMinesLeft() { return this.minesLeft; }

    /**
     * This sets how many mines are left.  They mines are decremented in
     * reduceMinesLeft each time the path hits one of these.
     * @param minesLeft  Integer - number of mines left
     */
    public void setMinesLeft(Integer minesLeft) { this.minesLeft = minesLeft; }

    /**
     * This gets the parent cell of the current cell.  The parent cell is the cell that traveled to this one.
     * @return MazePoint address of the cell's parent
     */
    private MazePoint getParent() {
        return this.parent;
    }

    /**
     * This sets the parent cell of the current cell in the current cell's MazeNode information.
     * @param parent Address of the cell that traveled to this one.
     */
    public void setParent(MazePoint parent) { this.parent = parent; }

    /**
     * Gets the path tracked by the current cell so far.
     * It's usually pulled from the parent by the child, and then added to by the child and stored in the child's cell.
     * It's also pulled at the end to display the final path traveled.
     * @return List of Strings that contains the path traveled.
     */
    @Nullable
    public LinkedList<String> getPathTrack() { return this.pathTrack; }

    /**
     * This sets the path traveled.
     * The parent's path has been incorporated into this, if it's being called while solving the maze.
     * @param pathTrack list of strings that contains the path traveled.
     */
    public void setPathTrack(LinkedList<String> pathTrack) { this.pathTrack = pathTrack; }

    /**
     * This checks to see if this MazeNode is the starting MazeNode for the maze.
     * @return is this the starting cell
     */
    private boolean isStart() {
        return this.start;
    }

    /**
     * This sets the MazeNode as the starting cell.
     * @TODO - This may already be set during the initial creation of the MazeNodes.
     */
    public void setStart()  { this.start = true; }

    /**
     * This sets the direction from which this cell was reached.
     * @TODO Check - feels like this has already been set as well, but this may be in a different context.
     * @param direction direction traveled to arrive at this cell.
     */
    public void setDirection(String direction) { this.direction = direction; }

}