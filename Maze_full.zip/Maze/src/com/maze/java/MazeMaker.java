package com.maze.java;

import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static java.lang.Integer.parseInt;

/**
 * Parses the file line it receives.
 * Creates the initial MazeNodes for each cell.
 * Returns the matrix of Maze Nodes
 *
 * Primary function is makeMaze, so this function is listed first after constructor.
 * @author cjromberger
 */
class MazeMaker implements GlobalConstants {

    private String mazeInfo;

    MazeMaker() {}

    /**
     * Core function for this class.  It creates the maze structure and figures out directions, start, end
     * and mines, by parsing and doing bitwise operations on the incoming file line.
     * @param sCurrentLine  Current Line from maze file
     * @return matrixInfo
     */
    @Nullable
    MazeInfo makeMaze(String sCurrentLine) {

        int counter = 0;
        int listSize;
        Integer numMinesAllowed = NUM_MINES_ALLOWED;

        List<String> matrixContents;
        LinkedList<MazeNode> childList; // want a clean list
        LinkedList<MazeNode> mazeNodesMatrix = new LinkedList<>();

        MazeInfo mazeInfo = new MazeInfo();
        MazeNode mNode;

        MazePoint cell;
        MazePoint endPoint = new MazePoint (-1, -1);
        MazePoint matrixDimensions;
        MazePoint startPoint = new MazePoint(-1, -1);

        String[] mazeLine;

        mazeLine = sCurrentLine.split("-");

        matrixDimensions = parseMatrixDimensions(mazeLine[0]);

        matrixContents = parseMatrixContents(mazeLine[1]);

        listSize = matrixContents.size();

        if(isCorrectSize(matrixDimensions, listSize)) {
            // verify there are enough maze items to fill matrix

            for (int x = 0; x < matrixDimensions.x; x++) {

                for (int y = 0; y < matrixDimensions.y; y++) {

                    cell = new MazePoint(x, y);

                    mNode = new MazeNode(cell);

                    int mazeItem = parseInt(matrixContents.get(counter));

                    // set all parent to -1, -1 for now.  They'll get real parents when the maze is traversed
                    mNode.setParent(new MazePoint(-1, -1)); // MazeNode function

                    if (this.isStart(mazeItem)) { //
                        //   System.out.println("START CELL -> x " + x + " y " + y);
                        mNode.setStart();
                        mNode.setParent(new MazePoint(-1, -1));
                        startPoint = cell;
                    }

                    if (this.isEnd(mazeItem)) {
                        //    System.out.println("END CELL -> x:" + x + " y:" + y);
                        mNode.setEnd();
                        endPoint = cell;

                    }

                    if (this.isMine(mazeItem)) {
                        mNode.setMine();
                    }

                    childList = this.makeChildList(mazeItem, cell, numMinesAllowed);

                    mNode.setChildren(childList);  // MazeNode function

                    mazeNodesMatrix.add(mNode); // adds this cell's MazeNode info into the list of cell information

                    counter++;
                }

            }

            // sets the meta data for the maze and then checks it for a few things before returning it to be solved.
            mazeInfo.setMazeNodesMatrix(mazeNodesMatrix);
            mazeInfo.setStartPoint(startPoint);
            mazeInfo.setEndPoint(endPoint);
            mazeInfo.setMatrixDimensions(matrixDimensions);
            mazeInfo.setNumMinesAllowed(numMinesAllowed);

            if (checkReady(mazeInfo.getStartPoint(), mazeInfo.getEndPoint())) {
                return mazeInfo;
            }
        }

        return null; // uhoh
    }

    /**
     * Parses the first part of a file line to figure out the dimensions of the maze.
     * @param fileLineSizeInfo The first piece of parsed information from the line in the incoming file.
     * @todo Come up with a better variable name, because there's a class called MazeInfo
     * @return
     */
    private MazePoint parseMatrixDimensions(String fileLineSizeInfo){

        MazePoint matrixDimensions = new MazePoint(0, 0);

        // separating the matrix size from the contents
        List<String> matchList = new ArrayList<>();
        Pattern regex = Pattern.compile("\\((.*?)\\)");
        Matcher regexMatcher = regex.matcher(fileLineSizeInfo);

        while (regexMatcher.find()) {//Finds Matching Pattern in String
            matchList.add(regexMatcher.group(1));//Fetching Group from String
        }

        String[] mazeSize = matchList.get(0).split(",");
        int x = parseInt(mazeSize[0]);
        int y = parseInt(mazeSize[1]);

        matrixDimensions.setMazePoints(x, y);

        return matrixDimensions;
    }

    /**
     * Parses the second part of a file line to figure out the dimensions of the maze.
     * @param fileLineContentInfo
     * @return Parses the first part of a file line to figure out the dimensions of the maze.
     */
    @NotNull
    private List<String> parseMatrixContents(String fileLineContentInfo)
    {
        String strMaze = fileLineContentInfo.replaceAll("\\[", "").replaceAll("]", "");

        return Arrays.asList(strMaze.split(","));

    }

    /**
     * Are the bitwise numbers equal the rows * columns?
     * @param matrixDimensions The x and y coordinates for the dimensions stored in a MazePoint class
     * @param listSize The size of the incoming list of bitwise numbers
     * @return
     */
    @Contract(pure = true)
    private boolean isCorrectSize(MazePoint matrixDimensions, int listSize) {
        if ((matrixDimensions.x * matrixDimensions.y) == listSize) {
            return true;
        }
        return false;
    }

    /**
     * Creates a list of the children for the current cell.  Adds that list to the current cell's MazeNode
     * @param mazeItem The bitwise code from the file for this cell
     * @param mazePoint The cell address of the current cell
     * @param numMinesAllowed
     * @return
     */
    private LinkedList<MazeNode> makeChildList(int mazeItem, MazePoint mazePoint, Integer numMinesAllowed)
    {

        int x = mazePoint.x;
        int y = mazePoint.y;
        // p is going to be the parent of these children
        LinkedList<MazeNode> childList = new LinkedList<>();
        MazeNode child;

//        StringBuilder sbCellContents  = new StringBuilder();
//        sbCellContents.append(p.getMazePointString());

        if ((mazeItem & UP) == UP) {
            child = new MazeNode(new MazePoint(x-1, y), mazePoint, U, numMinesAllowed);
            childList.add(child);
         //   sbCellContents.append(" up ");
        }

        if ((mazeItem & DOWN) == DOWN) {
            child = new MazeNode(new MazePoint(x + 1, y), mazePoint, D, numMinesAllowed);
            childList.add(child);
    //        sbCellContents.append(" down ");
        }

        if ((mazeItem & RIGHT) == RIGHT) {
            child = new MazeNode(new MazePoint(x, y + 1), mazePoint, R, numMinesAllowed);
            childList.add(child);
   //         sbCellContents.append(" right ");
        }

        if ((mazeItem & LEFT) == LEFT) {
            child = new MazeNode(new MazePoint(x, y - 1), mazePoint, L, numMinesAllowed);
            childList.add(child);
   //         sbCellContents.append(" left ");
        }

   //     System.out.println(sbCellContents.toString());

        return childList;

    }

    /**
     * Is this the starting cell?
     * @param mazeItem The incoming bitwise code for this cell
     * @return
     */
    @Contract(pure = true)
    private boolean isStart (int mazeItem) { return((mazeItem & START) == START);}

    /**
     * Is this the ending cell?
     * @param mazeItem The incoming bitwise code for this cell
     * @return
     */
    @Contract(pure = true)
    private boolean isEnd (int mazeItem) { return ((mazeItem & END) == END);}

    /**
     * Is this a mine cell?
     * @param mazeItem The incoming bitwise code for this cell
     * @return
     */
    @Contract(pure = true)
    private boolean isMine (int mazeItem) { return ((mazeItem & MINE) == MINE);}

    /**
     * Is the maze ready to be processed?
     * @param startPoint  The starting cell address
     * @param endPoint The ending cell address
     * @return
     */
    private boolean checkReady(MazePoint startPoint, MazePoint endPoint) {
        return (startPoint.isSet(startPoint) && endPoint.isSet(endPoint));
    }

    /**
     * Utility function for printing out each item on the list. Only needed for debugging.
     * @param list The list of MazeNodes.  Each MazeNode contains information about one cell.
     */
    void print(LinkedList<MazeNode> list) {
        int pCounter = 0;
        for( MazeNode item : list) {
            System.out.println("The MazeNode #" + pCounter + " in the list is: ");
            item.print();
            pCounter++;
            System.out.println();
            System.out.println();

        }

    }

}
