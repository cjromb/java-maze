package com.maze.java;

import java.util.LinkedList;

/**
 * Used to store the maze information returning from maze parsing.
 * Passed to the solveMaze function
 * @author cjromberger
 */
class MazeInfo {

    private Integer numMinesAllowed;

    private LinkedList<MazeNode> mazeNodesMatrix;

    private MazePoint endPoint;
    private MazePoint matrixDimensions;
    private MazePoint startPoint;


    public MazeInfo() {

    }

    /**
     * gets the end point from the newly parsed maze information
     * @return
     */
    MazePoint getEndPoint() {
        return endPoint;
    }

    /**
     * sets the end point from the newly parsed maze info before sending it off for solving.
     * @param endPoint the end point for the maze
     */
    void setEndPoint(MazePoint endPoint)
    {
        this.endPoint = endPoint;
    }

    /**
     * gets the dimensions of the maze (how many rows and columns)  Stores them in the two field class MazePoint
     * @return
     */
    MazePoint getMatrixDimensions() {
        return matrixDimensions;
    }

    /**
     * sets the x and y values for the maze
     * @param matrixDimensions
     */
    public void setMatrixDimensions(MazePoint matrixDimensions)
    {
        this.matrixDimensions = matrixDimensions;
    }

    /**
     * gets the MazeNodes of cell information to send off for solving.
     * @return
     */
    public LinkedList<MazeNode> getMazeNodesMatrix() {return mazeNodesMatrix;}

    /**
     * Sets the mazeNodes lists of cell information after parsing it from the file.
     * @param mazeNodesMatrix
     */
    public void setMazeNodesMatrix(LinkedList<MazeNode> mazeNodesMatrix)
    {
        this.mazeNodesMatrix = mazeNodesMatrix;
    }

    /**
     * Sends back the base number of mines allowed per path.  This value is currently stored in GlobalConstants.
     * It could be input from another place, like a command line or user interface.
     * @return
     */
    public Integer getNumMinesAllowed() {
        return this.numMinesAllowed;
    }

    /**
     * Sets the number of mines allowed before sending back the maze information for solving.
     * @param numMinesAllowed
     */
    public void setNumMinesAllowed(Integer numMinesAllowed)
    {
        this.numMinesAllowed = numMinesAllowed;
    }

    /**
     * Gets the starting point for the maze.
     * @return
     */
    public MazePoint getStartPoint() {
        return startPoint;
    }

    /**
     * sets the starting point for the maze after parsing before sending off for solving.
     */
    public void setStartPoint(MazePoint startPoint)
    {
        this.startPoint = startPoint;
    }


}
